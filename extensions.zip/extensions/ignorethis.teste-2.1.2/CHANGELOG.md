## Angular TypeScript Snippets Changelog

<a name="2.1.2"></a>
# 2.1.2 (2017-03-26)

* Added `ngForAsync` snippet
* Added `ngIfElse` snippet

<a name="2.0.0"></a>
# 2.0.0 (2017-01-23)

* Change prefix from `ng2-` to `a-` now that its just "Angular"
* Added `json` pipe snippets
