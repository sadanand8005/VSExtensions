var CompletionGlobals_1 = require("./CompletionGlobals");
/**
 * Gets the path to a commonJS file
 */
function GetCommonJSPath(inner) {
    const relativeTargetSplit = inner.path.replace(CompletionGlobals_1.CompletionGlobals.Root, "").split("/");
    const relativeUriSplit = CompletionGlobals_1.CompletionGlobals.Uri.replace(CompletionGlobals_1.CompletionGlobals.Root, "").split("/");
    relativeUriSplit.pop();
    const length = Math.max(relativeTargetSplit.length, relativeUriSplit.length);
    let path = "";
    let spacer = "";
    /// This is madness, need to come up with a better way of resolving this
    for (let i = 0; i < length; i++) {
        /// If we're equal, do nothing
        if (relativeUriSplit[i] && relativeTargetSplit[i] && relativeUriSplit[i] === relativeTargetSplit[i]) {
            continue;
        }
        else if (relativeUriSplit[i] && relativeTargetSplit[i] && relativeUriSplit[i] !== relativeTargetSplit[i]) {
            path += "../" + relativeTargetSplit[i];
        }
        else if (relativeUriSplit[i]) {
            path += spacer + relativeUriSplit[i];
        }
        else if (relativeTargetSplit[i]) {
            path += spacer + relativeTargetSplit[i];
        }
        /// Not possible to fail both
        /// First element doesn't need a slash (Nodev6)
        if (path.length > 0) {
            spacer = "/";
        }
    }
    /// CommonJS path is relative to where we are
    return "./" + path;
}
exports.GetCommonJSPath = GetCommonJSPath;
//# sourceMappingURL=CommonPathFinder.js.map