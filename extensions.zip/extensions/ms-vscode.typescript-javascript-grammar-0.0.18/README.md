## The Beta Version of the TypeScript Grammar 
 
We use this extension to distribute the Beta version of our new TypeScript grammar. Please file
any issues you find against https://github.com/Microsoft/TypeScript-TmLanguage
 
### License
The extension is made available under the following [Microsoft Software License Terms](https://github.com/sheetalkamat/TypeScript-TmLanguage-VsCode/blob/master/LICENSE.txt).

