class CommunicationMethods {
}
CommunicationMethods.NAMESPACE_UPDATE = "namespaceUpdate";
CommunicationMethods.TSCONFIG_UPDATE = "tsconfigUpdate";
CommunicationMethods.SAVE_REQUEST = "saveRequest";
CommunicationMethods.RESYNC = "resync";
module.exports = CommunicationMethods;
//# sourceMappingURL=CommunicationMethods.js.map