class CompletionGlobals {
}
exports.CompletionGlobals = CompletionGlobals;
//# sourceMappingURL=CompletionGlobals.js.map